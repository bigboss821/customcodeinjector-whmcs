<?php

if (!defined('WHMCS')) {
    die('Access denied.');
}

use WHMCS\Database\Capsule;

/**
 * Hook to inject custom code into the client area header.
 */
add_hook('ClientAreaHeadOutput', 1, function ($vars) {
    $headerCode = Capsule::table('tbladdonmodules')
        ->where('module', 'customcodeinjector')
        ->where('setting', 'headerCode')
        ->value('value');

    return $headerCode;
});

/**
 * Hook to inject custom code into the client area footer.
 */
add_hook('ClientAreaFooterOutput', 1, function ($vars) {
    $footerCode = Capsule::table('tbladdonmodules')
        ->where('module', 'customcodeinjector')
        ->where('setting', 'footerCode')
        ->value('value');

    return $footerCode;
});
