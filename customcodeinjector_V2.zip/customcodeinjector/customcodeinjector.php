<?php

if (!defined('WHMCS')) {
    die('Access denied.');
}

use WHMCS\Database\Capsule;

/**
 * Define addon module configuration.
 */
function customcodeinjector_config()
{
    return [
        'name' => 'Custom Code Injector',
        'description' => 'This addon allows you to inject custom header and footer code into the client area. Developed by Kazi Asraful Alom Rabbe from CyberDefendX.org.',
        'version' => '1.0',
        'author' => 'CyberDefendX.org - Kazi Asraful Alom Rabbe',
        'fields' => [
            'headerCode' => [
                'FriendlyName' => 'Header Code',
                'Type' => 'textarea',
                'Rows' => '10',
                'Cols' => '80',
                'Description' => 'Insert HTML/JS/CSS code to inject into the client area header.',
            ],
            'footerCode' => [
                'FriendlyName' => 'Footer Code',
                'Type' => 'textarea',
                'Rows' => '10',
                'Cols' => '80',
                'Description' => 'Insert HTML/JS/CSS code to inject into the client area footer.',
            ],
        ],
    ];
}

/**
 * Handle addon activation.
 */
function customcodeinjector_activate()
{
    return [
        'status' => 'success',
        'description' => 'Custom Code Injector has been activated successfully. Developed by Kazi Asraful Alom Rabbe from CyberDefendX.org.',
    ];
}

/**
 * Handle addon deactivation.
 */
function customcodeinjector_deactivate()
{
    return [
        'status' => 'success',
        'description' => 'Custom Code Injector has been deactivated successfully. Developed by Kazi Asraful Alom Rabbe from CyberDefendX.org.',
    ];
}

/**
 * Output page for the addon in the WHMCS admin area.
 */
function customcodeinjector_output($vars)
{
    $headerCode = Capsule::table('tbladdonmodules')
        ->where('module', 'customcodeinjector')
        ->where('setting', 'headerCode')
        ->value('value');

    $footerCode = Capsule::table('tbladdonmodules')
        ->where('module', 'customcodeinjector')
        ->where('setting', 'footerCode')
        ->value('value');

    echo '<h2>Custom Code Injector by CyberDefendX.org</h2>';
    echo '<h3>Header Code</h3>';
    echo '<pre>' . htmlentities($headerCode) . '</pre>';
    echo '<h3>Footer Code</h3>';
    echo '<pre>' . htmlentities($footerCode) . '</pre>';
}
